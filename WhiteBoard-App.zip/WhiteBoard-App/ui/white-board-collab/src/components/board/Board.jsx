import React from 'react';
import io from 'socket.io-client';
import './style.css';

class Board extends React.Component {
  timeout;
  socket = io.connect("http://localhost:3000");

  ctx;
  isDrawing = false;
  mouse = { x: 0, y: 0 }; // Define mouse as a class property
  last_mouse = { x: 0, y: 0 }; // Define last_mouse as a class property

  constructor(props) {
    super(props);

    this.socket.on("canvas-data", (data) => {
      var root = this;
      var interval = setInterval(function () {
        if (root.isDrawing) return;
        root.isDrawing = true;
        clearInterval(interval);
        var image = new Image();
        var canvas = document.querySelector('#board');
        var ctx = canvas.getContext('2d');
        image.onload = function () {
          ctx.drawImage(image, 0, 0);
          root.isDrawing = false;
        };
        image.src = data;
      }, 200);
    });
  }

  componentDidMount() {
    this.drawOnCanvas();
  }

  drawOnCanvas() {
    var canvas = document.querySelector('#board');
    this.ctx = canvas.getContext('2d');

    var sketch = document.querySelector('#sketch');
    var sketch_style = getComputedStyle(sketch);
    canvas.width = parseInt(sketch_style.getPropertyValue('width'));
    canvas.height = parseInt(sketch_style.getPropertyValue('height'));

    /* Mouse Capturing Work */
    canvas.addEventListener('mousemove', (e) => {
      this.last_mouse.x = this.mouse.x;
      this.last_mouse.y = this.mouse.y;

      this.mouse.x = e.pageX - canvas.offsetLeft;
      this.mouse.y = e.pageY - canvas.offsetTop;
    }, false);

    /* Drawing on Paint App */
    canvas.addEventListener('mousedown', (e) => {
      this.isDrawing = true;
      this.ctx.beginPath();
      this.ctx.moveTo(this.mouse.x, this.mouse.y);

      canvas.addEventListener('mousemove', this.onPaint, false);
    }, false);

    canvas.addEventListener('mouseup', (e) => {
      this.isDrawing = false;
      canvas.removeEventListener('mousemove', this.onPaint, false);
    }, false);
  }

  onPaint = () => {
    if (!this.isDrawing) return;
    this.ctx.lineTo(this.mouse.x, this.mouse.y);
    this.ctx.stroke();
    this.emitCanvasData();
  };

  emitCanvasData = () => {
    var canvas = document.querySelector('#board');
    var base64ImageData = canvas.toDataURL("image/png");
    this.socket.emit("canvas-data", base64ImageData);
  };

  render() {
    return (
      <div id="sketch" className="sketch">
        <canvas id="board"></canvas>
      </div>
    );
  }
}

export default Board;